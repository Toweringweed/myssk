from django.apps import AppConfig


class SkyuserConfig(AppConfig):
    name = 'skyuser'
